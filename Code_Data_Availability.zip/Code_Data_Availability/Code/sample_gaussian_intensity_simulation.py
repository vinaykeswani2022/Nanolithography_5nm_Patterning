
import numpy as np
import matplotlib.pyplot as plt

# Define parameters for Gaussian intensity distribution
x = np.linspace(-10, 10, 500)  # Distance in nm
sigma = 1.5  # Standard deviation representing feature size
intensity = np.exp(-x**2 / (2 * sigma**2))  # Gaussian intensity distribution

# Plot the intensity profile
plt.figure(figsize=(8, 5))
plt.plot(x, intensity, label='Intensity Profile (Gaussian)')
plt.title('Simulated Gaussian Intensity Distribution')
plt.xlabel('Distance (nm)')
plt.ylabel('Intensity (a.u.)')
plt.grid(True)
plt.legend()
plt.show()
